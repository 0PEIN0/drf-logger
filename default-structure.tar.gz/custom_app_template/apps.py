from django.apps import AppConfig


class {{app_name|title}}Config(AppConfig):
    name = '{{app_name}}'
