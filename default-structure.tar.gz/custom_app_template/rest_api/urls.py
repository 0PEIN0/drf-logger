from django.conf.urls import url

from ..rest_api import views

#declear your urls here
urlpatterns = [

]
